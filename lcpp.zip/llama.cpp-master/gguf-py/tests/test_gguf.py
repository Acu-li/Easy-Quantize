import gguf  # noqa: F401  # pyright: ignore[reportUnusedImport]

# TODO: add tests


def test_write_gguf() -> None:
    pass
